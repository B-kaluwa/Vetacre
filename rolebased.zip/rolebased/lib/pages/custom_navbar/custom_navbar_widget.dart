import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'custom_navbar_model.dart';
export 'custom_navbar_model.dart';

class CustomNavbarWidget extends StatefulWidget {
  const CustomNavbarWidget({
    super.key,
    required this.pageName,
  });

  final String? pageName;

  @override
  State<CustomNavbarWidget> createState() => _CustomNavbarWidgetState();
}

class _CustomNavbarWidgetState extends State<CustomNavbarWidget> {
  late CustomNavbarModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CustomNavbarModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 330.0,
      height: 80.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).noColor,
        borderRadius: BorderRadius.circular(24.0),
        shape: BoxShape.rectangle,
      ),
      child: Stack(
        children: [
          Container(
            width: 330.0,
            height: 80.0,
            decoration: BoxDecoration(
              color: FlutterFlowTheme.of(context).noColor,
              borderRadius: BorderRadius.circular(20.0),
            ),
            child: Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(50.0),
                  child: Image.asset(
                    Theme.of(context).brightness == Brightness.dark
                        ? 'assets/images/math-U5mHl-uACe0-unsplash.jpg'
                        : 'assets/images/jeremy-bishop-G9i_plbfDgk-unsplash.jpg',
                    width: 350.0,
                    height: 150.0,
                    fit: BoxFit.fill,
                  ),
                ),
                Padding(
                  padding:
                      const EdgeInsetsDirectional.fromSTEB(20.0, 12.0, 20.0, 15.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Align(
                        alignment: const AlignmentDirectional(-1.0, 0.0),
                        child: FlutterFlowIconButton(
                          borderRadius: 30.0,
                          borderWidth: 1.0,
                          buttonSize: 50.0,
                          fillColor:
                              FlutterFlowTheme.of(context).primaryBtnText,
                          icon: Icon(
                            Icons.wechat_outlined,
                            color: widget.pageName == 'login'
                                ? const Color(0xFF2219C7)
                                : const Color(0xFF0B0101),
                            size: 24.0,
                          ),
                          onPressed: () async {
                            context.pushNamed(
                              'login',
                              extra: <String, dynamic>{
                                kTransitionInfoKey: const TransitionInfo(
                                  hasTransition: true,
                                  transitionType: PageTransitionType.fade,
                                  duration: Duration(milliseconds: 2000),
                                ),
                              },
                            );
                          },
                        ),
                      ),
                      FlutterFlowIconButton(
                        borderRadius: 30.0,
                        borderWidth: 1.0,
                        buttonSize: 50.0,
                        fillColor: FlutterFlowTheme.of(context).primaryBtnText,
                        icon: Icon(
                          Icons.add_home_rounded,
                          color: widget.pageName == 'appointments'
                              ? const Color(0xFF2219C7)
                              : FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                          size: 24.0,
                        ),
                        onPressed: () async {
                          context.pushNamed(
                            'appointments',
                            extra: <String, dynamic>{
                              kTransitionInfoKey: const TransitionInfo(
                                hasTransition: true,
                                transitionType: PageTransitionType.fade,
                                duration: Duration(milliseconds: 2000),
                              ),
                            },
                          );
                        },
                      ),
                      FlutterFlowIconButton(
                        borderRadius: 30.0,
                        borderWidth: 1.0,
                        buttonSize: 50.0,
                        fillColor: FlutterFlowTheme.of(context).primaryBtnText,
                        icon: Icon(
                          Icons.topic_sharp,
                          color: widget.pageName == 'HomePage'
                              ? const Color(0xFF2219C7)
                              : const Color(0xFF0B0101),
                          size: 24.0,
                        ),
                        onPressed: () async {
                          context.pushNamed(
                            'HomePage',
                            extra: <String, dynamic>{
                              kTransitionInfoKey: const TransitionInfo(
                                hasTransition: true,
                                transitionType: PageTransitionType.fade,
                                duration: Duration(milliseconds: 2000),
                              ),
                            },
                          );
                        },
                      ),
                      Align(
                        alignment: const AlignmentDirectional(1.0, 0.0),
                        child: FlutterFlowIconButton(
                          borderRadius: 30.0,
                          borderWidth: 1.0,
                          buttonSize: 50.0,
                          fillColor:
                              FlutterFlowTheme.of(context).primaryBtnText,
                          icon: Icon(
                            Icons.location_history_sharp,
                            color: widget.pageName == 'profile_client'
                                ? const Color(0xFF2219C7)
                                : const Color(0xFF0B0101),
                            size: 24.0,
                          ),
                          onPressed: () async {
                            context.pushNamed(
                              'profile_client',
                              extra: <String, dynamic>{
                                kTransitionInfoKey: const TransitionInfo(
                                  hasTransition: true,
                                  transitionType: PageTransitionType.fade,
                                  duration: Duration(milliseconds: 2000),
                                ),
                              },
                            );
                          },
                        ),
                      ),
                    ].divide(const SizedBox(width: 12.0)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
