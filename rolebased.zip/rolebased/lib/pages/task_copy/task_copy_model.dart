import '/flutter_flow/flutter_flow_util.dart';
import 'task_copy_widget.dart' show TaskCopyWidget;
import 'package:flutter/material.dart';

class TaskCopyModel extends FlutterFlowModel<TaskCopyWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
