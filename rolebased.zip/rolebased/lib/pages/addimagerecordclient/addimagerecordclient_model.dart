import '/flutter_flow/flutter_flow_util.dart';
import 'addimagerecordclient_widget.dart' show AddimagerecordclientWidget;
import 'package:flutter/material.dart';

class AddimagerecordclientModel
    extends FlutterFlowModel<AddimagerecordclientWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for details widget.
  FocusNode? detailsFocusNode;
  TextEditingController? detailsTextController;
  String? Function(BuildContext, String?)? detailsTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    detailsFocusNode?.dispose();
    detailsTextController?.dispose();
  }
}
