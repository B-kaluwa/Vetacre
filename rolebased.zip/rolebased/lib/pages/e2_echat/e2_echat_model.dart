import '/flutter_flow/flutter_flow_util.dart';
import 'e2_echat_widget.dart' show E2EchatWidget;
import 'package:flutter/material.dart';

class E2EchatModel extends FlutterFlowModel<E2EchatWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
