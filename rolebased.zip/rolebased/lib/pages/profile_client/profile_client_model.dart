import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/custom_navbar/custom_navbar_widget.dart';
import 'profile_client_widget.dart' show ProfileClientWidget;
import 'package:flutter/material.dart';

class ProfileClientModel extends FlutterFlowModel<ProfileClientWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - Read Document] action in Text-userName widget.
  UserRecord? displayName;
  // Stores action output result for [Backend Call - Read Document] action in Text-emailAddress widget.
  UserRecord? email;
  // Model for CustomNavbar component.
  late CustomNavbarModel customNavbarModel;
  // State field(s) for Checkbox widget.
  bool? checkboxValue;

  @override
  void initState(BuildContext context) {
    customNavbarModel = createModel(context, () => CustomNavbarModel());
  }

  @override
  void dispose() {
    customNavbarModel.dispose();
  }
}
