import '/flutter_flow/flutter_flow_util.dart';
import 'imagerecordsclient_widget.dart' show ImagerecordsclientWidget;
import 'package:flutter/material.dart';

class ImagerecordsclientModel
    extends FlutterFlowModel<ImagerecordsclientWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
