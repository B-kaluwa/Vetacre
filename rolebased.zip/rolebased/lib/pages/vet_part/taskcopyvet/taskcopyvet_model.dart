import '/flutter_flow/flutter_flow_util.dart';
import 'taskcopyvet_widget.dart' show TaskcopyvetWidget;
import 'package:flutter/material.dart';

class TaskcopyvetModel extends FlutterFlowModel<TaskcopyvetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
