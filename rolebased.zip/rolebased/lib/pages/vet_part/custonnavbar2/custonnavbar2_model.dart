import '/flutter_flow/flutter_flow_util.dart';
import 'custonnavbar2_widget.dart' show Custonnavbar2Widget;
import 'package:flutter/material.dart';

class Custonnavbar2Model extends FlutterFlowModel<Custonnavbar2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
