import '/flutter_flow/flutter_flow_util.dart';
import 'addimagerecordv_widget.dart' show AddimagerecordvWidget;
import 'package:flutter/material.dart';

class AddimagerecordvModel extends FlutterFlowModel<AddimagerecordvWidget> {
  ///  State fields for stateful widgets in this component.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for details widget.
  FocusNode? detailsFocusNode;
  TextEditingController? detailsTextController;
  String? Function(BuildContext, String?)? detailsTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    detailsFocusNode?.dispose();
    detailsTextController?.dispose();
  }
}
