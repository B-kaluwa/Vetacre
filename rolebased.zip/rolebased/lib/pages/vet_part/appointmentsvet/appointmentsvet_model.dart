import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/pages/vet_part/custonnavbar2/custonnavbar2_widget.dart';
import 'appointmentsvet_widget.dart' show AppointmentsvetWidget;
import 'package:flutter/material.dart';

class AppointmentsvetModel extends FlutterFlowModel<AppointmentsvetWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for Checkbox widget.

  Map<TasksRecord, bool> checkboxValueMap1 = {};
  List<TasksRecord> get checkboxCheckedItems1 => checkboxValueMap1.entries
      .where((e) => e.value)
      .map((e) => e.key)
      .toList();

  // State field(s) for Checkbox widget.

  Map<TasksRecord, bool> checkboxValueMap2 = {};
  List<TasksRecord> get checkboxCheckedItems2 => checkboxValueMap2.entries
      .where((e) => e.value)
      .map((e) => e.key)
      .toList();

  // State field(s) for Checkbox widget.

  Map<TasksRecord, bool> checkboxValueMap3 = {};
  List<TasksRecord> get checkboxCheckedItems3 => checkboxValueMap3.entries
      .where((e) => e.value)
      .map((e) => e.key)
      .toList();

  // State field(s) for Checkbox widget.

  Map<TasksRecord, bool> checkboxValueMap4 = {};
  List<TasksRecord> get checkboxCheckedItems4 => checkboxValueMap4.entries
      .where((e) => e.value)
      .map((e) => e.key)
      .toList();

  // Model for custonnavbar2 component.
  late Custonnavbar2Model custonnavbar2Model;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;

  @override
  void initState(BuildContext context) {
    custonnavbar2Model = createModel(context, () => Custonnavbar2Model());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    tabBarController?.dispose();
    custonnavbar2Model.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
