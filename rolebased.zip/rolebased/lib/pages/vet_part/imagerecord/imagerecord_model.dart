import '/flutter_flow/flutter_flow_util.dart';
import 'imagerecord_widget.dart' show ImagerecordWidget;
import 'package:flutter/material.dart';

class ImagerecordModel extends FlutterFlowModel<ImagerecordWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
