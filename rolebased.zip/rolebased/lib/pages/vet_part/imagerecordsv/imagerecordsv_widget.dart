import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'imagerecordsv_model.dart';
export 'imagerecordsv_model.dart';

class ImagerecordsvWidget extends StatefulWidget {
  const ImagerecordsvWidget({
    super.key,
    required this.imageDoc,
  });

  final RecordsRecord? imageDoc;

  @override
  State<ImagerecordsvWidget> createState() => _ImagerecordsvWidgetState();
}

class _ImagerecordsvWidgetState extends State<ImagerecordsvWidget> {
  late ImagerecordsvModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => ImagerecordsvModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _model.unfocusNode.canRequestFocus
          ? FocusScope.of(context).requestFocus(_model.unfocusNode)
          : FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryText,
        body: SafeArea(
          top: true,
          child: Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(10.0, 0.0, 10.0, 0.0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(0.0, 20.0, 0.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      FlutterFlowIconButton(
                        borderColor: FlutterFlowTheme.of(context).primary,
                        borderRadius: 30.0,
                        borderWidth: 2.0,
                        buttonSize: 60.0,
                        fillColor: FlutterFlowTheme.of(context).primaryText,
                        icon: Icon(
                          Icons.arrow_back,
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          size: 36.0,
                        ),
                        onPressed: () async {
                          context.safePop();
                        },
                      ),
                      FlutterFlowIconButton(
                        borderColor: const Color(0xFF771826),
                        borderRadius: 30.0,
                        borderWidth: 3.0,
                        buttonSize: 60.0,
                        fillColor: FlutterFlowTheme.of(context).primaryText,
                        icon: FaIcon(
                          FontAwesomeIcons.trashAlt,
                          color:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          size: 36.0,
                        ),
                        onPressed: () {
                          print('IconButton pressed ...');
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      Container(
                        width: 360.0,
                        height: 550.0,
                        decoration: BoxDecoration(
                          color: FlutterFlowTheme.of(context).primaryText,
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8.0),
                          child: Image.network(
                            widget.imageDoc!.imager,
                            width: 300.0,
                            height: 200.0,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      AutoSizeText(
                        valueOrDefault<String>(
                          widget.imageDoc?.imageDetails,
                          'description',
                        ),
                        maxLines: 5,
                        style: FlutterFlowTheme.of(context)
                            .headlineMedium
                            .override(
                              fontFamily: 'Outfit',
                              color: FlutterFlowTheme.of(context)
                                  .secondaryBackground,
                              letterSpacing: 0.0,
                            ),
                      ),
                    ].divide(const SizedBox(height: 12.0)),
                  ),
                ),
              ].divide(const SizedBox(height: 6.0)),
            ),
          ),
        ),
      ),
    );
  }
}
