import '/flutter_flow/flutter_flow_util.dart';
import '/pages/vet_part/custonnavbar2/custonnavbar2_widget.dart';
import 'chatsvet_widget.dart' show ChatsvetWidget;
import 'package:flutter/material.dart';

class ChatsvetModel extends FlutterFlowModel<ChatsvetWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Model for custonnavbar2 component.
  late Custonnavbar2Model custonnavbar2Model;

  @override
  void initState(BuildContext context) {
    custonnavbar2Model = createModel(context, () => Custonnavbar2Model());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();

    custonnavbar2Model.dispose();
  }
}
