import '/flutter_flow/flutter_flow_util.dart';
import 'develop_copy_widget.dart' show DevelopCopyWidget;
import 'package:flutter/material.dart';

class DevelopCopyModel extends FlutterFlowModel<DevelopCopyWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
