import '/flutter_flow/flutter_flow_util.dart';
import 'imagerecord_client_widget.dart' show ImagerecordClientWidget;
import 'package:flutter/material.dart';

class ImagerecordClientModel extends FlutterFlowModel<ImagerecordClientWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
