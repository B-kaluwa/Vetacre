// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/vet_part/chatsvet/chatsvet_widget.dart' show ChatsvetWidget;
export '/pages/vet_part/appointmentsvet/appointmentsvet_widget.dart'
    show AppointmentsvetWidget;
export '/pages/vet_part/featuresvet/featuresvet_widget.dart'
    show FeaturesvetWidget;
export '/pages/signin/signin_widget.dart' show SigninWidget;
export '/pages/signup/signup_widget.dart' show SignupWidget;
export '/pages/vet_part/profile/profile_widget.dart' show ProfileWidget;
export '/pages/profile_client/profile_client_widget.dart'
    show ProfileClientWidget;
export '/pages/appointments/appointments_widget.dart' show AppointmentsWidget;
export '/pages/createprofile/createprofile_widget.dart'
    show CreateprofileWidget;
export '/pages/develop/develop_widget.dart' show DevelopWidget;
export '/pages/vet_part/createprofile_copy/createprofile_copy_widget.dart'
    show CreateprofileCopyWidget;
export '/pages/welcoming/welcoming_widget.dart' show WelcomingWidget;
export '/pages/directorypage/directorypage_widget.dart'
    show DirectorypageWidget;
export '/pages/profileview1/profileview1_widget.dart' show Profileview1Widget;
export '/pages/vet_part/profileview2/profileview2_widget.dart'
    show Profileview2Widget;
export '/pages/active/active_widget.dart' show ActiveWidget;
export '/pages/messaging/messaging_widget.dart' show MessagingWidget;
export '/pages/records_page/records_page_widget.dart' show RecordsPageWidget;
export '/pages/details_record/details_record_widget.dart'
    show DetailsRecordWidget;
export '/pages/vet_part/recordsvet_page/recordsvet_page_widget.dart'
    show RecordsvetPageWidget;
export '/pages/vet_part/details_recordvet/details_recordvet_widget.dart'
    show DetailsRecordvetWidget;
export '/pages/c_hats_page/c_hats_page_widget.dart' show CHatsPageWidget;
export '/pages/c_hat_page2/c_hat_page2_widget.dart' show CHatPage2Widget;
export '/pages/e2_echat/e2_echat_widget.dart' show E2EchatWidget;
export '/pages/activevet/activevet_widget.dart' show ActivevetWidget;
export '/pages/vet_part/messagingvet/messagingvet_widget.dart'
    show MessagingvetWidget;
export '/pages/vet_part/develop_copy/develop_copy_widget.dart'
    show DevelopCopyWidget;
export '/pages/vet_part/imagerecordsv/imagerecordsv_widget.dart'
    show ImagerecordsvWidget;
export '/pages/imagerecordsclient/imagerecordsclient_widget.dart'
    show ImagerecordsclientWidget;
