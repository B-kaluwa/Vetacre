import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class CHatsMessagesRecord extends FirestoreRecord {
  CHatsMessagesRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "createdby_ref" field.
  DocumentReference? _createdbyRef;
  DocumentReference? get createdbyRef => _createdbyRef;
  bool hasCreatedbyRef() => _createdbyRef != null;

  // "message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "seenby_ref" field.
  List<DocumentReference>? _seenbyRef;
  List<DocumentReference> get seenbyRef => _seenbyRef ?? const [];
  bool hasSeenbyRef() => _seenbyRef != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _date = snapshotData['date'] as DateTime?;
    _createdbyRef = snapshotData['createdby_ref'] as DocumentReference?;
    _message = snapshotData['message'] as String?;
    _seenbyRef = getDataList(snapshotData['seenby_ref']);
    _photo = snapshotData['photo'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('CHats_Messages')
          : FirebaseFirestore.instance.collectionGroup('CHats_Messages');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('CHats_Messages').doc(id);

  static Stream<CHatsMessagesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CHatsMessagesRecord.fromSnapshot(s));

  static Future<CHatsMessagesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CHatsMessagesRecord.fromSnapshot(s));

  static CHatsMessagesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CHatsMessagesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CHatsMessagesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CHatsMessagesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CHatsMessagesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CHatsMessagesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCHatsMessagesRecordData({
  DateTime? date,
  DocumentReference? createdbyRef,
  String? message,
  String? photo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date': date,
      'createdby_ref': createdbyRef,
      'message': message,
      'photo': photo,
    }.withoutNulls,
  );

  return firestoreData;
}

class CHatsMessagesRecordDocumentEquality
    implements Equality<CHatsMessagesRecord> {
  const CHatsMessagesRecordDocumentEquality();

  @override
  bool equals(CHatsMessagesRecord? e1, CHatsMessagesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.date == e2?.date &&
        e1?.createdbyRef == e2?.createdbyRef &&
        e1?.message == e2?.message &&
        listEquality.equals(e1?.seenbyRef, e2?.seenbyRef) &&
        e1?.photo == e2?.photo;
  }

  @override
  int hash(CHatsMessagesRecord? e) => const ListEquality()
      .hash([e?.date, e?.createdbyRef, e?.message, e?.seenbyRef, e?.photo]);

  @override
  bool isValidKey(Object? o) => o is CHatsMessagesRecord;
}
