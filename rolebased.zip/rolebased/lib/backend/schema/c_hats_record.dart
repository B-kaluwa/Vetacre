import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class CHatsRecord extends FirestoreRecord {
  CHatsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "date" field.
  DateTime? _date;
  DateTime? get date => _date;
  bool hasDate() => _date != null;

  // "createdby_ref" field.
  DocumentReference? _createdbyRef;
  DocumentReference? get createdbyRef => _createdbyRef;
  bool hasCreatedbyRef() => _createdbyRef != null;

  // "chat_title" field.
  String? _chatTitle;
  String get chatTitle => _chatTitle ?? '';
  bool hasChatTitle() => _chatTitle != null;

  // "recent_update" field.
  DateTime? _recentUpdate;
  DateTime? get recentUpdate => _recentUpdate;
  bool hasRecentUpdate() => _recentUpdate != null;

  // "members_ref" field.
  List<DocumentReference>? _membersRef;
  List<DocumentReference> get membersRef => _membersRef ?? const [];
  bool hasMembersRef() => _membersRef != null;

  // "folder_ref" field.
  DocumentReference? _folderRef;
  DocumentReference? get folderRef => _folderRef;
  bool hasFolderRef() => _folderRef != null;

  // "chat_photo" field.
  String? _chatPhoto;
  String get chatPhoto => _chatPhoto ?? '';
  bool hasChatPhoto() => _chatPhoto != null;

  // "recent_message_ref" field.
  DocumentReference? _recentMessageRef;
  DocumentReference? get recentMessageRef => _recentMessageRef;
  bool hasRecentMessageRef() => _recentMessageRef != null;

  // "recent_chat_message" field.
  String? _recentChatMessage;
  String get recentChatMessage => _recentChatMessage ?? '';
  bool hasRecentChatMessage() => _recentChatMessage != null;

  void _initializeFields() {
    _date = snapshotData['date'] as DateTime?;
    _createdbyRef = snapshotData['createdby_ref'] as DocumentReference?;
    _chatTitle = snapshotData['chat_title'] as String?;
    _recentUpdate = snapshotData['recent_update'] as DateTime?;
    _membersRef = getDataList(snapshotData['members_ref']);
    _folderRef = snapshotData['folder_ref'] as DocumentReference?;
    _chatPhoto = snapshotData['chat_photo'] as String?;
    _recentMessageRef =
        snapshotData['recent_message_ref'] as DocumentReference?;
    _recentChatMessage = snapshotData['recent_chat_message'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('CHats');

  static Stream<CHatsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CHatsRecord.fromSnapshot(s));

  static Future<CHatsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CHatsRecord.fromSnapshot(s));

  static CHatsRecord fromSnapshot(DocumentSnapshot snapshot) => CHatsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CHatsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CHatsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CHatsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CHatsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCHatsRecordData({
  DateTime? date,
  DocumentReference? createdbyRef,
  String? chatTitle,
  DateTime? recentUpdate,
  DocumentReference? folderRef,
  String? chatPhoto,
  DocumentReference? recentMessageRef,
  String? recentChatMessage,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'date': date,
      'createdby_ref': createdbyRef,
      'chat_title': chatTitle,
      'recent_update': recentUpdate,
      'folder_ref': folderRef,
      'chat_photo': chatPhoto,
      'recent_message_ref': recentMessageRef,
      'recent_chat_message': recentChatMessage,
    }.withoutNulls,
  );

  return firestoreData;
}

class CHatsRecordDocumentEquality implements Equality<CHatsRecord> {
  const CHatsRecordDocumentEquality();

  @override
  bool equals(CHatsRecord? e1, CHatsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.date == e2?.date &&
        e1?.createdbyRef == e2?.createdbyRef &&
        e1?.chatTitle == e2?.chatTitle &&
        e1?.recentUpdate == e2?.recentUpdate &&
        listEquality.equals(e1?.membersRef, e2?.membersRef) &&
        e1?.folderRef == e2?.folderRef &&
        e1?.chatPhoto == e2?.chatPhoto &&
        e1?.recentMessageRef == e2?.recentMessageRef &&
        e1?.recentChatMessage == e2?.recentChatMessage;
  }

  @override
  int hash(CHatsRecord? e) => const ListEquality().hash([
        e?.date,
        e?.createdbyRef,
        e?.chatTitle,
        e?.recentUpdate,
        e?.membersRef,
        e?.folderRef,
        e?.chatPhoto,
        e?.recentMessageRef,
        e?.recentChatMessage
      ]);

  @override
  bool isValidKey(Object? o) => o is CHatsRecord;
}
