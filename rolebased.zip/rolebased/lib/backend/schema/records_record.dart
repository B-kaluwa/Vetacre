import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';

class RecordsRecord extends FirestoreRecord {
  RecordsRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "details" field.
  String? _details;
  String get details => _details ?? '';
  bool hasDetails() => _details != null;

  // "createdt" field.
  DateTime? _createdt;
  DateTime? get createdt => _createdt;
  bool hasCreatedt() => _createdt != null;

  // "imager" field.
  String? _imager;
  String get imager => _imager ?? '';
  bool hasImager() => _imager != null;

  // "image_details" field.
  String? _imageDetails;
  String get imageDetails => _imageDetails ?? '';
  bool hasImageDetails() => _imageDetails != null;

  void _initializeFields() {
    _user = snapshotData['user'] as DocumentReference?;
    _title = snapshotData['title'] as String?;
    _details = snapshotData['details'] as String?;
    _createdt = snapshotData['createdt'] as DateTime?;
    _imager = snapshotData['imager'] as String?;
    _imageDetails = snapshotData['image_details'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Records');

  static Stream<RecordsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RecordsRecord.fromSnapshot(s));

  static Future<RecordsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RecordsRecord.fromSnapshot(s));

  static RecordsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RecordsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RecordsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RecordsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RecordsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RecordsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRecordsRecordData({
  DocumentReference? user,
  String? title,
  String? details,
  DateTime? createdt,
  String? imager,
  String? imageDetails,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'user': user,
      'title': title,
      'details': details,
      'createdt': createdt,
      'imager': imager,
      'image_details': imageDetails,
    }.withoutNulls,
  );

  return firestoreData;
}

class RecordsRecordDocumentEquality implements Equality<RecordsRecord> {
  const RecordsRecordDocumentEquality();

  @override
  bool equals(RecordsRecord? e1, RecordsRecord? e2) {
    return e1?.user == e2?.user &&
        e1?.title == e2?.title &&
        e1?.details == e2?.details &&
        e1?.createdt == e2?.createdt &&
        e1?.imager == e2?.imager &&
        e1?.imageDetails == e2?.imageDetails;
  }

  @override
  int hash(RecordsRecord? e) => const ListEquality().hash(
      [e?.user, e?.title, e?.details, e?.createdt, e?.imager, e?.imageDetails]);

  @override
  bool isValidKey(Object? o) => o is RecordsRecord;
}
