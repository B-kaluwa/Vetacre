import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyDtwuwQKEE-iR7rE6rLegdSWjNjurBvQus",
            authDomain: "vetcareapp-8dc9a.firebaseapp.com",
            projectId: "vetcareapp-8dc9a",
            storageBucket: "vetcareapp-8dc9a.appspot.com",
            messagingSenderId: "839861915629",
            appId: "1:839861915629:web:bff73cb8f504a9c011e1e4",
            measurementId: "G-EMJ0RBS50P"));
  } else {
    await Firebase.initializeApp();
  }
}
